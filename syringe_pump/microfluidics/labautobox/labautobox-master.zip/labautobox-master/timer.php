 
<?
$date = date('His');
echo $date;
?>

