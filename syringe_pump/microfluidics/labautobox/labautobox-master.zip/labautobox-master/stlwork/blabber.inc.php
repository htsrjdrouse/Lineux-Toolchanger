<?
     $key = "9arry";
     //$f = fopen("drrobot","r");
     $f = fopen("drrobotlab.json","r");
     //$jtmp = fread($f,filesize("drrobot"));
     $jtmp = fread($f,filesize("drrobotlab.json"));
?>
