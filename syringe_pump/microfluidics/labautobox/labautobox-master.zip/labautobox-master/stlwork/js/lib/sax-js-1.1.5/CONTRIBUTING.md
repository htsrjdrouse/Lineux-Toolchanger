**NO PATCHES WITHOUT A TEST**

**TEST MUST PASS WITH THE PATCH.**

**TEST MUST FAIL WITHOUT THE PATCH.**

**NO EXCEPTIONS.**

# EVERY PULL REQUEST MUST HAVE A TEST.

Seriously.  This is a very strict rule, and I will not bend it for any
patch, no matter how minor.

Write a test.
