
<?php
echo 'Now:       '. date('Ymds') ."\n";
?>

