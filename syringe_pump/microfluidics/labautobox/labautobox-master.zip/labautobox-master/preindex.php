<?
   header('Location: index.php');
?>
