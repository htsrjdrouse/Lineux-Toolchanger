 </div>
 <div class="col-md-6">

<? if ($_SESSION['labbotjson']['edittargets'] == 0){ ?>
 <? include('target.layout.inc.php'); ?>
</div>

<?} ?>

