17ul for 1ml disposable syringe rubber plungers
