<?
	$cmd = 'mosquitto_pub -t "labbot" -m "hello"';
	exec($cmd);
?>
