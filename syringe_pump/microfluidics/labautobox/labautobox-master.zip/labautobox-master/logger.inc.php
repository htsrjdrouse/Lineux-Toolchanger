  <? $mqttset = array("divmsg"=>"logger","topic"=>"logger","client"=>"client4")?>
  <? include('mqtt.log.js.inc.php'); ?> 
<ul>
<b><font size=1><div style="font-weight:bold" id="logger"></b></div><font>
</ul>
