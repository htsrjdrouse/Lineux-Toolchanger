import os
import subprocess,re

subprocess.Popen(["sudo","python3", "/var/www/html/labautobox/runmacro.py","ACM2","ACM1"]).pid
