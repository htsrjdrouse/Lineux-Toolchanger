<? include('header.inc.php');?>

<body>
<? include('functionslib.php');?>

<div class="header">
<h1>Deleted imaging files</h1>
</div>
<div class="section group">
<div class="col span_2_of_12" style="background-color:white">
</div>

<div class="col span_4_of_12" style="background-color:white">
</div>

<div class="col span_6_of_12" style="background-color:white">
</div>

</div>

</div>
</body>
</html>

