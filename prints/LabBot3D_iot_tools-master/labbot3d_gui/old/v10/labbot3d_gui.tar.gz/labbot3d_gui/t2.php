<? session_start(); ?>

here is teh saved variable: <?=$_SESSION['tstin']?><br>
