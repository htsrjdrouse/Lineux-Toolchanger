import tmecalcperline as te

tt = te.tmecalc('example')	


